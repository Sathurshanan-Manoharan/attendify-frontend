// import DashboardIcon from "@mui/icons-material/Dashboard";
// import AssignmentIcon from "@mui/icons-material/Assignment";
// import SettingsIcon from "@mui/icons-material/Settings";
// import AssessmentIcon from "@mui/icons-material/Assessment";
// import ViewTimelineIcon from "@mui/icons-material/ViewTimeline";

// const sidebarItems = [
//   { name: "Dashboard", path: "/", icon: <DashboardIcon /> },
//   { name: "Attendance", path: "/attendance", icon: <AssignmentIcon /> },
//   { name: "Timetable", path: "/timetable", icon: <ViewTimelineIcon /> },
//   { name: "Reports", path: "/reports", icon: <AssessmentIcon /> },
//   { name: "Settings", path: "/settings", icon: <SettingsIcon /> },
//   { name: "Add Student", path: "/addstudent", icon: <SettingsIcon /> },
//   { name: "Add Lecturer", path: "/addlecturer", icon: <SettingsIcon /> },
// ];

// export default sidebarItems;
