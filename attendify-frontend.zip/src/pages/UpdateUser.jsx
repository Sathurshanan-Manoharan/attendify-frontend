import { Typography } from "@mui/material";

export default function UpdateUser() {
  return (
    <Typography>Update User</Typography>
  )
}
