# Attendify

Attendify is an advanced attendance management system that utilises RFID technology.

